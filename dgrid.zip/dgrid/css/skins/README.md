This folder contains skins based on the Dijit themes (claro, tundra, soria, and nihilo),
as well as a number of other skins (e.g. cactus, sage, slate).

See the [Customizing Skins](../../doc/usage/Customizing-Skins.md) documentation for information on customizing skins.
