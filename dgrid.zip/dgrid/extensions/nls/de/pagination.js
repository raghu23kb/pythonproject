define({
	status: '${start} - ${end} von ${total} Ergebnissen',
	gotoFirst: 'Gehe zu erster Seite',
	gotoNext: 'Gehe zu nächster Seite',
	gotoPrev: 'Gehe zu vorheriger Seite',
	gotoLast: 'Gehe zu letzter Seite',
	gotoPage: 'Gehe zu Seite',
	jumpPage: 'Springe zu Seite'
});
