# util/mouse

The `util/mouse` module has been **removed** as of dgrid 0.4.
See the [0.4 Migration Guide](../../migrating/0.4-Migration.md#replacing-dgridutilmouse-with-dojomouse)
for information on using `dojo/mouse` for the same purposes.
