define(
//begin v1.x content
{
	"$locale": "zh-hant-hk",
	"decimalFormat-short": "000T",
	"nan": "非數值"
}
//end v1.x content
);