define(
//begin v1.x content
{
	"HKD_displayName": "hongkongi dollár",
	"CHF_displayName": "svájci frank",
	"JPY_symbol": "¥",
	"CAD_displayName": "kanadai dollár",
	"HKD_symbol": "HKD",
	"CNY_displayName": "Kínai jüan renminbi",
	"USD_symbol": "$",
	"AUD_displayName": "ausztrál dollár",
	"JPY_displayName": "japán jen",
	"CAD_symbol": "CAD",
	"USD_displayName": "USA-dollár",
	"EUR_symbol": "EUR",
	"CNY_symbol": "CNY",
	"GBP_displayName": "brit font sterling",
	"GBP_symbol": "GBP",
	"AUD_symbol": "AUD",
	"EUR_displayName": "euró"
}
//end v1.x content
);